﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class CfrmCalcultor : Form
    {
        static string text = "";
        public CfrmCalcultor()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            text = text + btn1.Text;
            txtText.Text = text;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            text = text + btn2.Text;
            txtText.Text = text;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            text = text + btn3.Text;
            txtText.Text = text;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            text = text + btn4.Text;
            txtText.Text = text;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            text = text + btn5.Text;
            txtText.Text = text;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            text = text + btn6.Text;
            txtText.Text = text;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            text = text + btn7.Text;
            txtText.Text = text;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            text = text + btn8.Text;
            txtText.Text = text;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            text = text + btn9.Text;
            txtText.Text = text;
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            text = text + btn0.Text;
            txtText.Text = text;
        }

        private void btnComma_Click(object sender, EventArgs e)
        {
            text = text + btnComma.Text;
            txtText.Text = text;
        }

        private void btnExponent10_Click(object sender, EventArgs e)
        {
            text = text + btnExponent10.Text + "^";
            txtText.Text = text;
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            text = text + btnPlus.Text;
            txtText.Text = text;
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            text = text + btnSubtract.Text;
            txtText.Text = text;
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            text = text + btnDivide.Text;
            txtText.Text = text;
        }


        private void btnEqual_Click(object sender, EventArgs e)
        {
            Prepare(ref text);
            DataTable dt = new DataTable();
            object v = dt.Compute(text, "");
            txtText.Text = v.ToString();
            text = "";
        }

        private void btnCloseBraacket_Click(object sender, EventArgs e)
        {
            text = text + btnCloseBraacket.Text;
            txtText.Text = text;
        }

        private void btnOpenBracket_Click(object sender, EventArgs e)
        {
            text = text + btnOpenBracket.Text;
            txtText.Text = text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtText.Text = text = "";
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            text = text + btnMultiply.Text;
            txtText.Text = text;
        }

        static void Prepare(ref string s) 
        {
            Cancel_X(ref s);
            Remove_exponential10(ref s);
        }
        static void Cancel_X(ref string s)
        {
           s = s.Replace('x', '*');
        }

        static void Remove_exponential10(ref string s)
        {
            string n = s;
            string m = "";
            string x="";
            string l = s;
            bool j=true;
            int k=0;
            float f = 0;
            if (n.IndexOf('^') < 0)
            {
                x = n;
            }
            else
            {
                
                while (n.IndexOf('^') >= 0 && n.Length>0)
                {
                    x += n.Substring(0, n.IndexOf('^') - 2);
                    int z = n.IndexOf('^');
                    int i;
                    for ( i = z + 1; i < n.Length; i++)
                    {
                        m += n[i];
                        j = int.TryParse(m, out k);
                        if (!j)
                        {
                            n = n.Substring(i);
                            x += Math.Pow(10, k);
                            break;
                        }
                        else
                        {
                        }
                    }
                    if (!j)
                    {
                        n = s.Substring(i + 1);
                    }
                    else
                    {
                        x += Math.Pow(10, k);
                        break;
                    }
                }

                s = x;
            }
            
        }
    }
}
